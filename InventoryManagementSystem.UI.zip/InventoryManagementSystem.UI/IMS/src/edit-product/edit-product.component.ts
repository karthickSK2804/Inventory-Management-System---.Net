import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { product } from '../product.model';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrl: './edit-product.component.css'
})
export class EditProductComponent {
  productId:number = 0;
  UpdateProductForm: FormGroup;
  errorMessage: string | null = null;
  product:product|null = null;
  constructor(private fb: FormBuilder,private route: ActivatedRoute,private service:ProductService, private router: Router) {
    this.route.params.subscribe(
     (params) => {
      this.productId = params['id'];
     });

     this.UpdateProductForm = this.fb.group({
      Name: ['', Validators.required],
      Price: ['', Validators.required],
      Stock: ['', Validators.required]
    });
  }

  ngOnInit()
  {
    this.service.GetAllProducts().subscribe((value)=>{
      let products = value.find(x=>x.id == this.productId);
      this.UpdateProductForm.get('Name')?.patchValue(products?.name);
      this.UpdateProductForm.get('Price')?.patchValue(products?.price);
      this.UpdateProductForm.get('Stock')?.patchValue(products?.stock);
    },(err)=>{
      console.log(err);
    })
  }

  onSubmit() {
    if (this.UpdateProductForm.valid) {

      const userData = {
        Name: this.UpdateProductForm.value.Name,
        Price: this.UpdateProductForm.value.Price,
        Stock: this.UpdateProductForm.value.Stock,
      };

      this.product = new product(this.productId, userData.Name, userData.Price, userData.Stock);

      this.service.UpdateProduct(this.product).subscribe((value) => {
        this.resetForm();
        this.router.navigateByUrl('/allitems');
      }, (err) => {
        this.router.navigateByUrl('/allitems');
      });

    } else {
      this.errorMessage = 'Form is not valid';
    }
  }

  resetForm() {
    this.UpdateProductForm.reset();
    this.errorMessage = null; // Reset error message
  }
}
