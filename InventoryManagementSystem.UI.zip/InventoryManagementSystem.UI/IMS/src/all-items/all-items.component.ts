import { Component } from '@angular/core';
import { ProductService } from '../product.service';
import { product } from '../product.model';

@Component({
  selector: 'app-all-items',
  templateUrl: './all-items.component.html',
  styleUrl: './all-items.component.css'
})
export class AllItemsComponent {

  products: product[] = [];

  constructor(private service: ProductService) {

  }

  ngOnInit() {
    this.GetProducts();   
  }

  GetProducts() {
    this.service.GetAllProducts().subscribe((value) => {
      this.products = value;
    },
      (err) => {
        console.log(err);
      })
  }

  DeleteProduct(productId:number)
  {
    this.service.DeleteProduct(productId).subscribe((value)=>{
      this.GetProducts();
      window.location.reload();
    },(err)=>{
      this.GetProducts();
      window.location.reload();
    })
  }

  OrderProduct(productId:number)
  {
    this.service.OrderProduct(productId).subscribe((value)=>{
      this.GetProducts();
      window.location.reload();
    },(err)=>{
      this.GetProducts();
      window.location.reload();
    })
  }
}
