import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { product } from '../product.model';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.css'
})
export class AddProductComponent {
  AddProductForm: FormGroup;
  errorMessage: string | null = null;
  product:product|null = null;
  constructor(private fb: FormBuilder, private router: Router,private service:ProductService) {
    this.AddProductForm = this.fb.group({
      Name: ['', Validators.required],
      Price: ['', Validators.required],
      Stock: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.AddProductForm.valid) {

      const userData = {
        Name: this.AddProductForm.value.Name,
        Price: this.AddProductForm.value.Price,
        Stock: this.AddProductForm.value.Stock,
      };

      this.product = new product(0, userData.Name, userData.Price, userData.Stock);

      this.service.CreateProduct(this.product).subscribe((value) => {
        this.resetForm();
        this.router.navigateByUrl('/allitems');
      }, (err) => {
        this.router.navigateByUrl('/allitems');
      });

    } else {
      this.errorMessage = 'Form is not valid';
    }
  }

  resetForm() {
    this.AddProductForm.reset();
    this.errorMessage = null; // Reset error message
  }
}
