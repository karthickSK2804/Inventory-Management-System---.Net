export class product {
    id: number = 0;
    name: string;
    price: number;
    stock: number;

    constructor(Id:number,Name:string,Price:number,Stock:number)
    {
        this.id = Id;
        this.name = Name;
        this.price = Price;
        this.stock = Stock;
    }
}