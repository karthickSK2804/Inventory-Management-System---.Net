import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { product } from './product.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private readonly apiUrl = "https://localhost:44363/";

  constructor(private http: HttpClient) {
  }

  GetAllProducts(): Observable<product[]> {
    return this.http.get<product[]>(`${this.apiUrl}Product/GetProducts`);
  }

  CreateProduct(product: product) {
    return this.http.post(`${this.apiUrl}product/CreateProduct`, product, { observe: 'response' });
  }

  UpdateProduct(product: product) {
    return this.http.put(`${this.apiUrl}product/UpdateProduct`, product, { observe: 'response' });
  }

  DeleteProduct(productId: number) {
    return this.http.delete(`${this.apiUrl}product/DeleteProduct?Id=${productId}`);
  }

  OrderProduct(productId: number) {
    return this.http.get(`${this.apiUrl}order/Order?Id=${productId}`);
  }
}
