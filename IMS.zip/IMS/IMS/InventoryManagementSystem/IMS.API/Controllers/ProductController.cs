﻿using IMS.API.Constants;
using IMS.BAL.ServiceContracts;
using IMS.DAL.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace IMS.API.Controllers
{
    [Route("Product")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _service;
        public ProductController(IProductService service)
        {
            _service = service;
        }
        [HttpGet(nameof(GetProducts))]
        public IActionResult GetProducts()
        {
            List<Product>? products = _service.GetProducts();

            if (products is { Count: 0 })
            {
                return NotFound(Responses.Notfound);
            }

            return Ok(products);
        }

        [HttpPost(nameof(CreateProduct))]
        public IActionResult CreateProduct([FromBody] Product product)
        {
            bool IsSuccess = _service.AddProduct(product);

            if(IsSuccess)
            {
                return Ok(Responses.ProductCreated);
            }
            else
            {
                return BadRequest(Responses.Error);
            }
        }

        [HttpPut(nameof(UpdateProduct))]
        public IActionResult UpdateProduct([FromBody] Product product)
        {
            bool IsSuccess = _service.UpdateProduct(product);

            if (IsSuccess)
            {
                return Ok(Responses.ProductUpdated);
            }
            else
            {
                return BadRequest(Responses.Error);
            }
        }

        [HttpDelete(nameof(DeleteProduct))]
        public IActionResult DeleteProduct([FromQuery] int Id)
        {
            bool IsSuccess = _service.DeleteProduct(Id);

            if (IsSuccess)
            {
                return Ok(Responses.ProductDeleted);
            }
            else
            {
                return BadRequest(Responses.Error);
            }
        }
    }
}
