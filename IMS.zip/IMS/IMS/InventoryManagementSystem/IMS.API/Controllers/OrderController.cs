﻿using IMS.API.Constants;
using IMS.BAL.ServiceContracts;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace IMS.API.Controllers
{
    [Route("order")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _service;
        public OrderController(IOrderService service)
        {
            _service = service;
        }

        [HttpGet(nameof(Order))]
        public IActionResult Order([FromQuery] int Id)
        {
            bool isSuccess = _service.Order(Id);

            if(isSuccess)
            {
                return Ok(Responses.OrderCreated);
            }
            else
            {
                return BadRequest(Responses.Error);
            }
        }
    }
}
