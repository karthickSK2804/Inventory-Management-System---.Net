﻿namespace IMS.API.Constants
{
    public static class Responses
    {
        public const string Notfound = "No data found";

        public const string ProductCreated = "Product created Successfully";

        public const string ProductUpdated = "Product updated Successfully";

        public const string ProductDeleted = "Product deleted Successfully";

        public const string OrderCreated = "Order placed successfully";

        public const string Error = "Something went wrong";
    }
}
