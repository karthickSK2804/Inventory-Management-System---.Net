﻿using IMS.BAL.ServiceContracts;
using IMS.DAL.RepositoryContracts;

namespace IMS.BAL.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repos;
        public OrderService(IOrderRepository repos)
        {
            _repos = repos;
        }
        public bool Order(int Id)
        {
            return _repos.Order(Id);
        }
    }
}
