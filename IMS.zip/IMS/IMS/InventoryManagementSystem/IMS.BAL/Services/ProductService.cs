﻿using IMS.BAL.ServiceContracts;
using IMS.DAL.Exceptions;
using IMS.DAL.Models;
using IMS.DAL.RepositoryContracts;

namespace IMS.BAL.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _repository;
        public ProductService(IProductRepository repository)
        {
            _repository = repository;
        }
        public bool AddProduct(Product product)
        {
            return _repository.AddProduct(product);
        }

        public bool DeleteProduct(int Id)
        {
            if (Id <= 0)
            {
                throw new ProductException("Product Id should be greater than 0");
            }

            return _repository.DeleteProduct(Id);
        }

        public List<Product>? GetProducts()
        {
            return _repository.GetProducts();
        }

        public bool UpdateProduct(Product product)
        {
            return _repository.UpdateProduct(product);
        }
    }
}
