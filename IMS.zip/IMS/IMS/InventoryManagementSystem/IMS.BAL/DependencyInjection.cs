﻿using IMS.BAL.ServiceContracts;
using IMS.BAL.Services;
using Microsoft.Extensions.DependencyInjection;

namespace IMS.BAL
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddBusinessLayer(this IServiceCollection services)
        {
            services.AddTransient<IProductService, ProductService>();

            services.AddTransient<IOrderService, OrderService>();

            return services;
        }
    }
}
