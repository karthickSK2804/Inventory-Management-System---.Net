﻿namespace IMS.BAL.ServiceContracts
{
    public interface IOrderService
    {
        bool Order(int Id);
    }
}
