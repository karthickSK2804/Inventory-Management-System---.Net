﻿using IMS.DAL.Models;

namespace IMS.BAL.ServiceContracts
{
    public interface IProductService
    {
        bool AddProduct(Product product);
        bool UpdateProduct(Product product);
        bool DeleteProduct(int Id);
        List<Product>? GetProducts();
    }
}
