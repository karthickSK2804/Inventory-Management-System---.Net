﻿using IMS.DAL.Exceptions;
using IMS.DAL.Models;
using IMS.DAL.RepositoryContracts;

namespace IMS.DAL.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly IProductRepository _product;
        public OrderRepository(IProductRepository product)
        {
            _product = product;
        }
        public bool Order(int Id)
        {
            Product? availProduct = _product.ProductList.Find(x => x.Id == Id);

            if(availProduct is null)
            {
                throw new OrderException("Product does not exist");
            }

            if (availProduct is { Stock: <= 0 })
            {
                throw new OrderException("Stock not exist");
            }

            _product.UpdateProduct(new()
            {
                Id = Id,
                Name = availProduct.Name,
                Stock = availProduct.Stock - 1,
                Price = availProduct.Price
            });

            return true;
        }
    }
}
