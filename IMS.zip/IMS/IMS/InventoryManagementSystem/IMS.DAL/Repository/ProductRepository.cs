﻿using IMS.DAL.Models;
using IMS.DAL.RepositoryContracts;

namespace IMS.DAL.Repository
{
    public class ProductRepository : IProductRepository
    {
        private static List<Product> Products = new();
        public List<Product> ProductList { get; set; }
        public ProductRepository()
        {
            ProductList = Products;
        }
        public bool AddProduct(Product product)
        {
            if(Products is { Count: 0 })
            {
                product.Id = 1;
            }

            if (Products is { Count: > 0 })
            {
                int previousId = Products.Max(x => x.Id);

                product.Id = previousId + 1;
            }

            Products.Add(product);

            return true;
        }

        public bool DeleteProduct(int Id)
        {
            Product? availProduct = Products.Find(x => x.Id == Id);

            if(availProduct is { })
            {
                Products.Remove(availProduct);

                return true;
            }
            else
            {
                return false;
            }
        }
        public List<Product>? GetProducts()
        {
            return Products;
        }

        public bool UpdateProduct(Product product)
        {
            Product? availProduct = Products.Find(x => x.Id == product.Id);

            if(availProduct is null)
            {
                return false;
            }

            if(availProduct is { })
            {
                availProduct.Name = product.Name;

                availProduct.Stock = product.Stock;

                availProduct.Price = product.Price;
            }

            return true;
        }
    }
}
