﻿using IMS.DAL.Exceptions;

namespace IMS.DAL.Models
{
    public class Product
    {
        public int Id { get; set; }

        private string _Name;
        public string? Name
        {
            get
            {
                return _Name;
            }
            set
            {
                if (value is null || value is { Length: 0})
                {
                    throw new ProductException("Name is Required");
                }

                _Name = value;
            }
        }

        private decimal _Price;
        
        public decimal Price
        {
            get
            {
                return _Price;
            }
            set
            {
                if(value is 0)
                {
                    throw new ProductException("Price should be greater than 0");
                }

                _Price = value;

            }
        }


        private decimal _Stock;

        public decimal Stock
        {
            get
            {
                return _Stock;
            }
            set
            {
                if (value < 0)
                {
                    throw new ProductException("Stock should not be less than 0");
                }

                _Stock = value;

            }
        }
    }
}
