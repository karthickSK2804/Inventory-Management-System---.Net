﻿using IMS.DAL.Models;

namespace IMS.DAL.RepositoryContracts
{
    public interface IProductRepository
    {
        List<Product> ProductList { get; set; }
        bool AddProduct(Product product);
        bool UpdateProduct(Product product);
        bool DeleteProduct(int Id);
        List<Product>? GetProducts();
    }
}
