﻿namespace IMS.DAL.RepositoryContracts
{
    public interface IOrderRepository
    {
        bool Order(int Id);
    }
}
