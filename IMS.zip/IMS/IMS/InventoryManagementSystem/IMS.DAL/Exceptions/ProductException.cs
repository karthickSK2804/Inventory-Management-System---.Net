﻿namespace IMS.DAL.Exceptions
{
    public class ProductException : Exception
    {
        public ProductException(string message) : base(message)
        {

        }

        public ProductException() : base()
        {
        }

        public ProductException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}
