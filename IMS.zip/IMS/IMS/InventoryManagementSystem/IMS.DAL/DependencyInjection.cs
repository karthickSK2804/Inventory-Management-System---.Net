﻿using IMS.DAL.Repository;
using IMS.DAL.RepositoryContracts;
using Microsoft.Extensions.DependencyInjection;

namespace IMS.DAL
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddDataLayer(this IServiceCollection services)
        {
            services.AddTransient<IProductRepository, ProductRepository>();

            services.AddTransient<IOrderRepository, OrderRepository>();

            return services;
        }
    }
}
